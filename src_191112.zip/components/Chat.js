import React, { Component } from 'react';

class Chat extends Component {
    render() {
        return (
            <div>
                chat
            </div>
        )
    }
}

export default Chat;